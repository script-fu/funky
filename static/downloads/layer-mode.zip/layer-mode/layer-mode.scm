#!/usr/bin/env gimp-script-fu-interpreter-3.0
;; =============================================================================
;; Purpose: Set the active layers to a particular blend mode
;;
;; A Set of Script-Fu plug-ins that sets the selected layers to a
;; particular blend mode
;;
;; Access these plugin from Layer > Stack > Layer Mode
;; =============================================================================

;; Copyright 2024, Mark Sweeney, Under GNU GENERAL PUBLIC LICENSE Version 3

;; Global variables
(define debug #f)

;; =============================================================================
;; Main Normal Mode
(define (script-fu-layer-mode-normal image drawables)
  (gimp-image-undo-group-start image)
  (layers-set-mode drawables LAYER-MODE-NORMAL)
  (gimp-image-undo-group-end image))

;; -----------------------------------------------------------------------------

(script-fu-register-filter
  "script-fu-layer-mode-normal"
  "Layer Mode Normal"
  "Sets the selected layers to layer blend mode normal"
  "Mark Sweeney"
  "Under GNU GENERAL PUBLIC LICENSE Version 3"
  "2025"
  "*"
  SF-ONE-OR-MORE-DRAWABLE)

(script-fu-menu-register
  "script-fu-layer-mode-normal"
  "<Image>/Layer/Stack")

;; =============================================================================
;; Main Multiply Mode
(define (script-fu-layer-mode-multiply image drawables)
  (gimp-image-undo-group-start image)
  (layers-set-mode drawables LAYER-MODE-MULTIPLY)
  (gimp-image-undo-group-end image))

(script-fu-register-filter
  "script-fu-layer-mode-multiply"
  "Layer Mode Multiply"
  "Sets the selected layers to layer blend mode multiply"
  "Mark Sweeney"
  "Under GNU GENERAL PUBLIC LICENSE Version 3"
  "2025"
  "*"
  SF-ONE-OR-MORE-DRAWABLE)

(script-fu-menu-register
  "script-fu-layer-mode-multiply"
  "<Image>/Layer/Stack")

;; =============================================================================
;; Library Functions

;; Purpose: Utility operations and helper functions for Script-Fu plugins
;;
;; This is a collection of utility functions for common operations
;; in Script-Fu plugins, including path management, list manipulation, messaging,
;; and control flow utilities. These functions can be loaded into any Script-Fu
;; plugin to provide reusable utilities, helping to streamline the development of plugins.
;; =============================================================================

(define warning #t)

;; Purpose: Ensures the given input is a list.
;; Converts a vector to a list or wraps other single values in a list if needed.
(define (ensure-list input)
  (cond
    ;; If the input is already a list, return it as-is
    ((list? input)
     input)
    ;; If the input is a vector, convert it to a list
    ((vector? input)
     (vector->list input))
    ;; If the input is null, return an empty list
    ((null? input)
     '())
    ;; Otherwise, wrap the input in a list
    (else
     (list input))))

;; Purpose: Returns the first item of a list or vector. Warns if the input is
;;          invalid or empty.
(define (first-item collection)
  (cond
    ;; Handle non-empty lists
    ((and (list? collection) (not (null? collection)))
     (list-ref collection 0))
    ;; Handle non-empty vectors
    ((and (vector? collection) (> (vector-length collection) 0))
     (vector-ref collection 0))
    ;; Invalid or empty input
    (else
     (begin
       (warning-message "first-item: Expected a non-empty list or vector, but received: " collection)
       #f))))

;; Purpose: Unwrap a single-element () list or handle empty lists. Warns if the input is not a valid list or not a single-element list.
(define (list->item list)
  (cond
    ((null? list)
     (debug-message "list->item: Input is an empty list, returning '()")
     '())
    ((and (list? list) (not (list? (car list))) (= 1 (length list)))
     (car list))
    (else
     (debug-message "list->item: Input is not a single-element list, returning the list.")
     list)))

;; Purpose: Display a message in GIMP's message console.
(define (message . items)
  (gimp-message (apply concat items)))

;; Purpose: Display a debug message.
(define (debug-message . items)
  (when debug (message "> " (apply concat items))))

;; Purpose: Display a warning message.
(define (warning-message . items)
  (if warning
    (message "Warning: " (apply concat items)))
    #f)

;; Purpose: Serialize a list of items into a single string, handling numbers,
;;          booleans, and nested lists.
(define (list->string list)
  (if (list? list)
      (string-append "list: \n" (string-join (map serialize-item list) "\n"))
      (warning-message "list->string: Input is not a list!")))

;; Purpose: Converts various Scheme data types (lists, vectors, pairs, etc.)
;;          into a string representation
(define (serialize-item item)
  (cond
    ((and (list? item) (null? item)) "\"\"")           ; Empty list
    ((and (string? item) (string=? item "")) "\"\"")   ; Empty string
    ((list? item) (list->string item))                ; Nested list
    ((vector? item)                                   ; Handle vectors
     (string-append "#("
                    (string-join (map serialize-item (vector->list item)) " ")
                    ")"))
    ((pair? item)                                     ; Handle pairs
     (string-append "("
                    (serialize-item (car item))
                    " . "
                    (serialize-item (cdr item))
                    ")"))
    ((number? item) (number->string item))            ; Numbers
    ((symbol? item) (symbol->string item))            ; Symbols
    ((boolean? item) (if item "#t" "#f"))             ; Booleans
    ((string? item) item)                             ; Strings
    (else (warning-message "serialize-item: Unsupported item type!" item))))

;; Purpose: Concatenate multiple items into a single string, handling numbers,
;;          booleans, lists, and other types.
(define (concat . items)
  (apply string-append (map serialize-item items)))

;; Purpose: Join a list of strings with a delimiter
(define (string-join list delimiter)
  (let loop ((remaining list)
             (result ""))
    (cond
      ((null? remaining) result)  ;; Base case: no more elements
      ((null? (cdr remaining))    ;; Last element: add without delimiter
       (string-append result (car remaining)))
      (else
       (loop (cdr remaining)
             (string-append result (car remaining) delimiter))))))

;; Purpose: Check if an item is valid, returning #t or #f.
(define (item-is-valid? item)
  (if (number? item)
    (= (list->item (gimp-item-id-is-valid item)) 1)
    #f))

;; Purpose: Returns #t if the item is a layer, otherwise returns #f
(define (item-is-layer? item)
  (and (item-is-valid? item)
       (= 1 (list->item (gimp-item-id-is-layer item)))))

;; Purpose: Returns #t if the item is a mask, otherwise returns #f
(define (item-is-layer-mask? item)
  (and (item-is-valid? item)
       (= 1 (list->item (gimp-item-id-is-layer-mask item)))))

;; =============================================================================
;; Purpose: Layer Utilities for Script-Fu Plugins
;;
;; This module provides a collection of layer related functions
;; =============================================================================

;; Purpose: Returns a layer if given a mask of a layer, a vector of layers,
;;          a list of layers or a single layer ID.
;;          Typical use is to filter the user selection of drawables to be a
;;          single layer and not a mask.
(define (ensure-layer item)
  (cond
    ;; Case 1: `item` is a vector or a list
    ((or (vector? item) (list? item))
     (let ((layer (first-item item)))
       (if (item-is-layer-mask? layer)
           (layer-from-mask layer)
           layer)))
    ;; Case 2: `item` is a single layer mask
    ((item-is-layer-mask? item)
     (layer-from-mask item))
    ;; Case 3: `item` is a single layer
    ((item-is-layer? item)
     item)
    ;; Default case: Return #f if it does not match the above.
    (else #f)))

;; Purpose: Returns a layers mask, otherwise returns #f
(define (layer-from-mask item)
  (if (item-is-valid? item)
    (let ((mask (list->item (gimp-layer-from-mask item))))
      (if (= mask -1)
        #f
        mask))
    #f))

;; Purpose: Set the layer mode of a collection of Layers
(define (layers-set-mode layers blend-mode)
  ;; Process each layer
  (for-each
    (lambda (layer)
      (gimp-layer-set-mode (ensure-layer layer) blend-mode))
    (ensure-list layers)))
